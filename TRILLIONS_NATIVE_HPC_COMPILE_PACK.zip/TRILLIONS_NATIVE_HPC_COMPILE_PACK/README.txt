TRILLIONS NATIVE HPC COMPILE PACK

This pack adds a real N-API C++ native addon skeleton for:
- AVX/AVX2/FMA compile path
- __m256 style vector operations
- native benchmark endpoint-ready .node binary
- REAL_ONLY_OR_UNAVAILABLE doctrine

It does not fake CUDA, GPU, MPI, RDMA, InfiniBand, or AVX512 runtime execution.

Install into your Codespaces project:
  unzip TRILLIONS_NATIVE_HPC_COMPILE_PACK.zip
  cp -R TRILLIONS_NATIVE_HPC_COMPILE_PACK/native ./native
  cd native
  npm install
  npx node-gyp configure
  npx node-gyp build
  node test_native.js

Expected compiled addon:
  native/build/Release/trillions_native.node

Your existing app.js probes already look for common native addon paths, including build/Release/trillions_native.node.
If needed, copy:
  cp native/build/Release/trillions_native.node ./build/Release/trillions_native.node
