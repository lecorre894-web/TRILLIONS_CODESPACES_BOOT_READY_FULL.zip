#include <napi.h>
#include <cmath>
#include <cstdint>
#include <chrono>

#if defined(__AVX2__)
#include <immintrin.h>
#endif

static Napi::Object Capabilities(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();
  Napi::Object o = Napi::Object::New(env);

#if defined(__AVX__)
  o.Set("avx_compiled", true);
#else
  o.Set("avx_compiled", false);
#endif

#if defined(__AVX2__)
  o.Set("avx2_compiled", true);
#else
  o.Set("avx2_compiled", false);
#endif

#if defined(__AVX512F__)
  o.Set("avx512f_compiled", true);
#else
  o.Set("avx512f_compiled", false);
#endif

#if defined(__FMA__)
  o.Set("fma_compiled", true);
#else
  o.Set("fma_compiled", false);
#endif

  o.Set("honesty", "compiled native capabilities only; runtime CPU support still depends on host/container");
  return o;
}

static Napi::Float64Array VecAddF64(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();
  if (info.Length() < 2 || !info[0].IsTypedArray() || !info[1].IsTypedArray()) {
    Napi::TypeError::New(env, "Expected two Float64Array arguments").ThrowAsJavaScriptException();
    return Napi::Float64Array::New(env, 0);
  }

  auto a = info[0].As<Napi::Float64Array>();
  auto b = info[1].As<Napi::Float64Array>();
  size_t len = std::min(a.ElementLength(), b.ElementLength());
  auto out = Napi::Float64Array::New(env, len);

  double* pa = a.Data();
  double* pb = b.Data();
  double* po = out.Data();

  size_t i = 0;

#if defined(__AVX2__)
  for (; i + 4 <= len; i += 4) {
    __m256d va = _mm256_loadu_pd(pa + i);
    __m256d vb = _mm256_loadu_pd(pb + i);
    __m256d vc = _mm256_add_pd(va, vb);
    _mm256_storeu_pd(po + i, vc);
  }
#endif

  for (; i < len; ++i) {
    po[i] = pa[i] + pb[i];
  }

  return out;
}

static Napi::Object NativeBench(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();

  uint32_t n = 1000000;
  uint32_t rounds = 10;
  if (info.Length() > 0 && info[0].IsNumber()) n = info[0].As<Napi::Number>().Uint32Value();
  if (info.Length() > 1 && info[1].IsNumber()) rounds = info[1].As<Napi::Number>().Uint32Value();
  if (n < 1024) n = 1024;
  if (n > 50000000) n = 50000000;
  if (rounds < 1) rounds = 1;
  if (rounds > 200) rounds = 200;

  std::vector<double> a(n), b(n), c(n);
  for (uint32_t i = 0; i < n; ++i) {
    a[i] = (double)(i % 1024) * 0.001;
    b[i] = (double)((i * 7) % 1024) * 0.002;
  }

  auto t0 = std::chrono::high_resolution_clock::now();
  double checksum = 0.0;

  for (uint32_t r = 0; r < rounds; ++r) {
    size_t i = 0;
#if defined(__AVX2__)
    for (; i + 4 <= n; i += 4) {
      __m256d va = _mm256_loadu_pd(a.data() + i);
      __m256d vb = _mm256_loadu_pd(b.data() + i);
      __m256d vc = _mm256_fmadd_pd(va, vb, va);
      _mm256_storeu_pd(c.data() + i, vc);
    }
#endif
    for (; i < n; ++i) {
      c[i] = a[i] * b[i] + a[i];
    }
    checksum += c[(r * 9973) % n];
  }

  auto t1 = std::chrono::high_resolution_clock::now();
  double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
  double ops = (double)n * (double)rounds * 2.0;
  double gflops = ops / (ms / 1000.0) / 1e9;

  Napi::Object o = Napi::Object::New(env);
  o.Set("status", "NATIVE_AVX_BENCH_COMPLETE");
  o.Set("n", n);
  o.Set("rounds", rounds);
  o.Set("duration_ms", ms);
  o.Set("ops_estimated", ops);
  o.Set("gflops_estimated", gflops);
  o.Set("checksum", checksum);
#if defined(__AVX2__)
  o.Set("path", "AVX2_FMA_IF_HOST_SUPPORTS");
#else
  o.Set("path", "SCALAR_FALLBACK");
#endif
  o.Set("honesty", "native addon benchmark; compare only same host/method; not LINPACK/HPL");
  return o;
}

static Napi::Object Init(Napi::Env env, Napi::Object exports) {
  exports.Set("capabilities", Napi::Function::New(env, Capabilities));
  exports.Set("vecAddF64", Napi::Function::New(env, VecAddF64));
  exports.Set("nativeBench", Napi::Function::New(env, NativeBench));
  return exports;
}

NODE_API_MODULE(trillions_native, Init)
