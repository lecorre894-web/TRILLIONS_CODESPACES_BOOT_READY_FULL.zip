{
  "targets": [
    {
      "target_name": "trillions_native",
      "sources": [ "avx_kernel.cc" ],
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")"
      ],
      "dependencies": [
        "<!(node -p \"require('node-addon-api').gyp\")"
      ],
      "defines": [
        "NAPI_DISABLE_CPP_EXCEPTIONS"
      ],
      "conditions": [
        [ "OS=='linux'", {
          "cflags_cc": [
            "-std=c++17",
            "-O3",
            "-march=native",
            "-mtune=native",
            "-mavx",
            "-mavx2",
            "-mfma"
          ]
        }]
      ]
    }
  ]
}
