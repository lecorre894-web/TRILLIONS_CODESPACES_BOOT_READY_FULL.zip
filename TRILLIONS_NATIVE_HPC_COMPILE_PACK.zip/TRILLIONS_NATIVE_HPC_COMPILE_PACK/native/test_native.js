const addon = require("./build/Release/trillions_native.node");

console.log("CAPABILITIES");
console.log(JSON.stringify(addon.capabilities(), null, 2));

const n = Number(process.env.NATIVE_N || 1000000);
const rounds = Number(process.env.NATIVE_ROUNDS || 20);
console.log("BENCH");
console.log(JSON.stringify(addon.nativeBench(n, rounds), null, 2));

const a = new Float64Array([1,2,3,4]);
const b = new Float64Array([10,20,30,40]);
console.log("VEC_ADD", Array.from(addon.vecAddF64(a,b)));
