#!/usr/bin/env bash
set -euo pipefail

echo "===== TRILLIONS NATIVE HPC COMPILE ====="
echo "Doctrine: REAL_ONLY_OR_UNAVAILABLE. No fake AVX/GPU claim."

ROOT="${1:-$(pwd)}"
NATIVE_DIR="$ROOT/native"

if [ ! -d "$NATIVE_DIR" ]; then
  echo "ERROR: native directory not found: $NATIVE_DIR"
  exit 1
fi

cd "$NATIVE_DIR"

echo "Node: $(node -v 2>/dev/null || echo unavailable)"
echo "NPM : $(npm -v 2>/dev/null || echo unavailable)"
echo "G++ : $(g++ --version 2>/dev/null | head -1 || echo unavailable)"
echo "CPU flags:"
(lscpu 2>/dev/null | grep -E 'Model name|Flags|Architecture' || true)

npm install
npx node-gyp configure
npx node-gyp build

echo "===== BUILD OUTPUT ====="
ls -lah build/Release || true

echo "===== NATIVE TEST ====="
node test_native.js

echo "===== COPY HINT ====="
echo "Expected addon path for app.js probes:"
echo "$NATIVE_DIR/build/Release/trillions_native.node"
