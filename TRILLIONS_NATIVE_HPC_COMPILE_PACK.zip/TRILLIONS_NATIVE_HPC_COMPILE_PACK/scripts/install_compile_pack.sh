#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-.}"

mkdir -p "$TARGET/native"
cp -R native/* "$TARGET/native/"
echo "Installed native compile pack into $TARGET/native"
echo "Run:"
echo "  bash scripts/compile_native_hpc.sh $TARGET"
